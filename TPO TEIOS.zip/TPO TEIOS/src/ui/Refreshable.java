package ui;

/**
 * Interfaz simple para componentes que pueden refrescar su contenido.
 */
public interface Refreshable {
    void refresh();
}

