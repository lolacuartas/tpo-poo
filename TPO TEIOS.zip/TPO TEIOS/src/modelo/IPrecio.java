package modelo;
import java.math.BigDecimal;

// Interfaz que define un objeto con precio del dominio

public interface IPrecio {

    java.math.BigDecimal precio();

}
