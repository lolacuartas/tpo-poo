package modelo;

public enum UnidadMedida {KILO, GRAMO, LITRO, MILILITRO, UNIDAD}
