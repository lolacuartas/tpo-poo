package modelo;

// Interfaz que define un objeto identificable del dominio

public interface IIdentificable <ID> {

    ID id();

}
