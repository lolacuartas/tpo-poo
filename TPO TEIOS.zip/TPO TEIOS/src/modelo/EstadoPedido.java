package modelo;

public enum EstadoPedido {
    PENDIENTE, ENVIADO, RECIBIDO, CANCELADO
}
